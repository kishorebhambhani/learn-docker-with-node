# learn-docker-with-node

A staged, hands-on path for Node.js developers learning Docker - from
"what is a container" through to sharing images on Docker Hub and
publishing them to a private registry (Azure Container Registry).

## Who this is for

Developers comfortable with Node.js/Express who are new to Docker, or
want a structured refresher. No prior Docker knowledge assumed.

## How this repo is organized

Each stage lives in its own numbered folder and is **fully
self-contained**, with its own Dockerfile, app code, and README. You can
open any single folder and run it without needing anything from the
others. The stages are numbered in a recommended learning order, though
not every stage depends on the previous stage's workflow. Each stage
introduces one new concept at a time.

```
learn-docker-with-node/
├── 01-hello-docker/            # image basics: build, run
├── 02-push-pull-registry/      # sharing images via a registry
├── 03-docker-compose/          # Compose syntax: docker run flags → docker-compose.yml
├── 04-multi-container-compose/ # connect the app to Redis with Compose networking
├── 05-bind-mounts/             # mount local code for live development edits
└── README.md                   # you are here
```

Each stage has a `.dockerignore`, `Dockerfile`, app code (`main.js`,
`package.json`, and `package-lock.json`), and a `README.md` explaining
what's new and how to run it. Stages 3 onward also have a
`docker-compose.yml`. The stage READMEs contain the actual test/run
instructions.

## Roadmap

| Stage | Folder | What it teaches |
|---|---|---|
| 1 | [`01-hello-docker`](01-hello-docker) | Building an image, running a container |
| 2 | [`02-push-pull-registry`](02-push-pull-registry) | Pushing/pulling images via a registry (Docker Hub) |
| 3 | [`03-docker-compose`](03-docker-compose) | Run the Stage 1 app with Compose, building the image locally |
| 4 | [`04-multi-container-compose`](04-multi-container-compose) | Connect the app to a Redis service using Compose service-name networking |
| 5 | [`05-bind-mounts`](05-bind-mounts) | Mount local code into a container for live development edits with a bind mount and `nodemon` |
| 6 | `06-multi-env-compose` *(coming soon)* | Configure development and production Compose setups: build locally for development, run a tagged image in production |
| 7 | `07-persistent-volumes` *(coming soon)* | Use a named volume to keep PostgreSQL data when its container is recreated |
| 8 | `08-cicd-github-actions` *(coming soon)* | Build and push images to Docker Hub automatically with GitHub Actions |
| 9 | `09-azure-acr` *(coming soon)* | Publish and pull images with Azure Container Registry, a private registry |

## Pre-requisites

- **Docker Desktop** - [Download](https://www.docker.com/products/docker-desktop/).
  Must be running before any `docker` command, or you'll see
  `error during connect: this error may indicate that the docker
  daemon is not running`.
- **Node.js** (v18+) and **npm** - [Download](https://nodejs.org/).
  Needed for a stage's optional local verification step, but not
  required to build or run any app in a container. The bind-mount stage
  can be checked locally with `npm install` and `node main.js` to confirm
  the HTTP response before or after using Docker Compose.
- A free [Docker Hub](https://hub.docker.com/) account - needed for
  stage 2. Later stages may use Docker Hub, another registry, or Azure
  Container Registry.

Verify installations:

```bash
docker -v
node -v
npm -v
```

## Terminal and Ctrl+C

Run the commands in a terminal opened in the stage folder. You can use
the VS Code integrated terminal with PowerShell selected, or a separate
PowerShell window. The `bash` labels on command blocks are for formatting;
the Docker commands shown here also work in PowerShell.

When a command is still running in the foreground, press `Ctrl+C` in
that same terminal tab or window to interrupt it. For example, it stops
the local Node.js server or an attached `docker run`/`docker compose up`.
`Ctrl+C` is a keyboard shortcut, not a command to type. It does not stop
a container started in the background with `-d`; use `docker stop` or
`docker compose down` for those.

## Structure

```bash
learn-docker-with-node/
├── README.md                       # top-level map: what this repo is, how to use it, link to each stage
├── LICENSE
├── .gitignore
├── .github/
│   ├── pull_request_template.md
│   └── CODEOWNERS
│
├── 01-hello-docker/
│   ├── README.md
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── package.json
│   ├── package-lock.json
│   └── main.js
├── 02-push-pull-registry/
│   ├── README.md
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── package.json
│   ├── package-lock.json
│   └── main.js
├── 03-docker-compose/
│   ├── README.md
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── package.json
│   ├── package-lock.json
│   └── main.js
├── 04-multi-container-compose/
│   ├── README.md
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── package.json
│   ├── package-lock.json
│   └── main.js
├── 05-bind-mounts/
│   ├── README.md
│   ├── .dockerignore
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── package.json
│   ├── package-lock.json
│   └── main.js
```

## General Docker commands reference

These apply across every stage, regardless of what's being taught:

```bash
docker ps                                   # list running containers
docker ps -a                                # list all containers, including stopped ones
docker images                               # list images on your machine
docker stop <container_id_or_name>          # gracefully stop a running container
docker start <container_id_or_name>         # start a stopped container
docker rm <container_id_or_name>            # remove a stopped container
docker rmi <image>                          # remove an image (remove its containers first)
docker logs <container_id_or_name>          # view a container's output
```

Registry commands introduced in stage 2:

```bash
docker login [registry]                                             # authenticate with Docker Hub or another registry
docker tag <image> <registry>/<namespace>/<repository>:<tag>         # add a registry-qualified name to an image
docker push <registry>/<namespace>/<repository>:<tag>                # upload an image to a registry
docker pull <registry>/<namespace>/<repository>:<tag>                # download an image from a registry
```

Compose commands introduced in stage 3:

```bash
docker compose up                           # build (if needed) and start all services in the file
docker compose up -d                        # same, but detached (background)
docker compose up --build                   # force a rebuild even if the image already exists
docker compose down                         # stop and remove containers started by the compose file
docker compose ps                           # list containers managed by the compose file
docker compose logs -f                      # follow logs from all services
```

Each stage's README covers its own command sequence, options, and
examples in more detail, including anything specific to that stage.

## Contribute

Create a branch and open a PR - the description will auto-populate
from the repo's PR template.
