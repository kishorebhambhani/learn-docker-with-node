# learn-docker-with-node — Roadmap & Decisions

This document exists so the reasoning behind this repo's structure isn't
lost — paste it into a new conversation to restore context on what's been
built, what's planned, and *why* it's organized this way.

## Core principle

**Each stage teaches exactly one new concept.** Nothing is bundled. This
was a deliberate correction made partway through planning — an earlier
draft tried to introduce Compose syntax and multi-container networking
(Redis) in the same stage, which was flagged as overwhelming for a
learner who'd only just finished single-container basics. Every stage
added since follows this rule, and any future stage should too.

## Roadmap status

| Stage | Folder | Teaches | Status |
|---|---|---|---|
| 1 | `01-hello-docker` | Building an image, running a container | Pre-existing, untouched |
| 2 | `02-push-pull-registry` | Pushing/pulling images via Docker Hub | Pre-existing, untouched |
| 3 | `03-docker-compose` | Compose syntax — `docker run` flags → `docker-compose.yml`. Same app as `01`/`02` (their code is identical) | Built |
| 4 | `04-multi-container-compose` | Add Redis and connect services through Compose networking and service-name DNS | Planned |
| 5 | `05-bind-mounts` | Mount local code into a running container for live development edits | Planned |
| 6 | `06-multi-env-compose` | Separate development and production Compose configuration; development builds locally, production runs a tagged image | Planned |
| 7 | `07-persistent-volumes` | Use a named volume with Postgres so data survives container recreation; contrast with the stage 5 bind mount | Planned |
| 8 | `08-cicd-github-actions` | Automate image builds and pushes to Docker Hub with GitHub Actions | Not started |
| 9 | `09-azure-acr` | Publish to and pull from Azure Container Registry, extending the registry workflow to a private registry | Not started |

## Key decisions and the reasoning behind them

**Redis over Postgres for the networking stage (4).** Redis needs no
schema, starts almost instantly, and has near-zero setup — so the *only*
new idea a learner absorbs in that stage is "two containers, one
network, service-name DNS." Postgres would drag in connection
strings, schema setup, and container-startup-timing problems
(`depends_on` only waits for the container to start, not for Postgres
inside it to be ready) — each of which deserves its own attention rather
than competing with the networking lesson.

**Bind mounts got their own stage (5) instead of being folded into
multi-env config.** Originally, mounting source code for hot-reload was
going to be introduced as a side detail inside the multi-env stage. That
was reconsidered — if a learner hits bind mounting for the first time
buried inside a different lesson, they absorb it passively rather than
understanding it. Teaching it standalone first also sets up a cleaner
contrast later: stage 7's named volumes get explained *against* the bind
mount the learner already understands, rather than introducing both
volume types at once.

**Persistence (Postgres + named volumes) deferred to its own stage (7),
not bundled with networking (4).** Same "one concept per stage" logic —
persistence and inter-container networking are different problems that
happen to both commonly involve a database. Isolating them meant stage 7
could use the "lose data without a volume, keep it with one"
before/after demo as its core teaching device, which wouldn't land as
clearly if networking concepts were competing for attention in the same
stage.

**Stage 6's dev/prod split should mirror how these images actually get
used.** Local dev continuously rebuilds as code changes — that's `build:`
+ the bind mount + `nodemon` from stage 5. Production doesn't rebuild on
the server at all — it pulls the exact image already built and pushed in
stage 2. Modeling that with `image: <registry>/<user>/repo:tag` in
`docker-compose.prod.yml` (instead of `build: .`) closes the loop back to
stage 2's registry lesson in a way that reflects real practice, not just
a syntax alternative.

## Planned Stage 6 design

When Stage 6 is built, its Compose files should model local development
and production differently:
- **`docker-compose.yml`** (base) — drops `build: .`, keeps only shared
  settings (ports, base env vars)
- **`docker-compose.override.yml`** (dev) — adds `build: .` + bind mount
  + `nodemon`
- **`docker-compose.prod.yml`** (prod) — adds `image:
  <registry>/<username>/docker-node-image:latest` instead of building

The production image should be the image published through the Stage 2
registry workflow. This keeps production from rebuilding on the server
and makes the connection between the registry and environment-specific
Compose configuration concrete.

## File-set convention every stage follows

```
NN-stage-name/
├── README.md              # what's new in this stage, how to test it, what's next
├── .dockerignore
├── Dockerfile
├── docker-compose.yml      # from stage 3 onward
├── package.json
├── package-lock.json
└── main.js
```

Stage 6 additionally has `docker-compose.override.yml` and
`docker-compose.prod.yml`. Stages 1–2 predate the Compose convention and
have no `docker-compose.yml`.

## Repo-wide conventions worth preserving in future stages

- Every stage is fully self-contained — runnable without referencing any
  other folder.
- Dockerfiles are heavily commented for teaching purposes, not terse.
- Each stage's `README.md` ends with a **What's next** section pointing
  to the following stage.
- The root `README.md` roadmap table, folder tree, and "Structure"
  section must all be kept in sync whenever a stage is added — this has
  been a recurring source of drift and is worth double-checking each time.
